You might need to download python first to run the program
If there is any trouble you can contact @notgreenfloppa on discord


you also need to use NBT names e.g deepslate_diamond_ore, wither, netherite_sword

Sections refer to type of data to collect (same item could be in different locations which is why there are sections)

There are total 9 Sections:



mined
used
crafted
broken
picked_up
dropped

killed_by
killed

custom

since NBT names for "custom" aren't obvious they will be listed below


animals_bred
clean_armor (leather armor cleaned with cauldron)
guster_banner_pattern (same thing as above but with a banner)
open_barrel 
bell_ring
eat_cake_slice
fill_cauldron
open_chest
damage_absorbed (damage taken by yellow hearts)
damage_blocked_by_shield
damage_dealt
damage_dealt_absorbed (damage dealt to yellow hearts)
damage_resisted (potion effect ressistance)
damage_dealt_resisted (potion effect ressistance)
damage_taken
inspect_dispenser
climb_one_cm
crouch_one_cm
fall_one_cm
fly_one_cm
sprint_one_cm
swim_one_cm (swum)
walk_one_cm
walk_on_water_one_cm 
walk_under_water_one_cm
boat_one_cm
aviate_one_cm (elytra)
happy_ghast_one_cm
horse_one_cm
minecart_one_cm
pig_one_cm
strider_one_cm
inspect_dropper
open_enderchest
fish_caught
leave_game
inspect_hopper
interact_with_anvil
interact_with_beacon
interact_with_blast_furnace
interact_with_brewingstand
interact_with_campfire
interact_with_cartography_table
interact_with_crafting_table
interact_with_furnace
interact_with_grindstone
interact_with_lectern
interact_with_loom
interact_with_smithing_table
interact_with_smoker
interact_with_stonecutter
drop
enchant_item
jump
mob_kills
play_record
play_noteblock
tune_noteblock
deaths
pot_flower
player_kills
raid_trigger
raid_win
clean_shulker_box (with cauldron)
open_shulker_box
sneak_time
talked_to_villager
target_hit
play_time
time_since_death
time_since_rest
total_world_time
sleep_in_bed
traded_with_villager
trigger_trapped_chest
use_cauldron